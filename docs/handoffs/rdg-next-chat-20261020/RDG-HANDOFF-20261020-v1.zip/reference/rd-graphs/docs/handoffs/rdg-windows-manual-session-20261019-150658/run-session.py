from pathlib import Path
from importlib.machinery import SourceFileLoader
import json,time,signal
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
F=SourceFileLoader('windows_manual_fixture',str(ROOT/'tests/rdg-workflow.acceptance.test.py')).load_module()
H=SourceFileLoader('windows_manual_helper',str(ROOT/'tools/rdg-workflow-helper.py')).load_module()
fixture=F.Workflow('test_whole_future_execution_withdrawal_new_variant_and_history')
fixture.setUp();session=None;running=True
def stop(*args):
 global running
 running=False
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
try:
 w=fixture.w
 ops=[w.add('A1'),w.add('A2')]
 ops[0]['action']['title']='Первый тестовый Action'
 ops[1]['action']['title']='Второй тестовый Action'
 w.apply(ops)
 one=fixture.place('S-A1','A1')
 one['timeConstraints']=[
  {'type':'notBefore','at':'2026-10-21','strength':'hard','basis':'Тестовая дата начала'},
  {'type':'deadline','at':'2026-10-25','strength':'hard','basis':'Тестовый срок, не обязательство проекта'}]
 two=fixture.place('S-A2','A2')
 two['timeConstraints'][0]['at']='2026-10-23'
 two['sequence']=[{'before':'S-A1','after':'S-A2'}]
 fixture.owner(fixture.placement_request([one,two]))
 editor=H.Editor(fixture.root,fixture.rel,w.home/'graphs',w.rel,w.store,w.token,tools=w.home/'tools')
 session=H.FileSession(editor,OUT/'session')
 def save():
  view=editor.snapshot()
  (OUT/'latest-view.json').write_text(json.dumps(view,ensure_ascii=False,indent=2)+'\n')
 save()
 (OUT/'READY.json').write_text(json.dumps({'active':True,'kind':'synthetic Windows manual test',
  'ttlSeconds':7200,'viewerVersion':'2.2.6','folder':str(OUT/'session'),'realUserGraphsChanged':False},indent=2)+'\n')
 print('READY: synthetic file session; no network listener; 120 minute lifetime',flush=True)
 until=time.monotonic()+7200
 while running and time.monotonic()<until:
  if session.process_once():save()
  if (OUT/'stop').exists():break
  time.sleep(0.1)
finally:
 if session:session.close()
 (OUT/'CLOSED.json').write_text(json.dumps({'active':False,'syntheticOnly':True})+'\n')
 fixture.doCleanups()
 print('CLOSED',flush=True)
