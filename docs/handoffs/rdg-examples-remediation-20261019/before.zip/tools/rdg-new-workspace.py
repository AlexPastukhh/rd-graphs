#!/usr/bin/env python3
"""Create a real editable RDG workspace from a user-specified goal, without decisions.

This is a project initializer, not a generator of fictional acceptance events.
Existing workspaces and historical/template graphs are never overwritten.
"""
import argparse
import importlib.machinery
import json
import os
import re
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
GRAPHS=ROOT/"graphs"
WRITER=importlib.machinery.SourceFileLoader("rdg_writer",str(ROOT/"tools"/"graph-apply.py")).load_module()
INDEX=importlib.machinery.SourceFileLoader("rdg_index",str(ROOT/"tools"/"graph-index.py")).load_module()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--slug", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--root-id", required=True)
    parser.add_argument("--root-title", required=True)
    parser.add_argument("--identity-space", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args=parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]*",args.slug):
        raise ValueError("slug must contain ascii lower-case letters, digits, - or _")
    for label,value in (("title",args.title),("root-id",args.root_id),
                        ("root-title",args.root_title),("identity-space",args.identity_space)):
        if not value.strip():
            raise ValueError(label+" must be nonempty")
    graph={
      "schemaVersion":1,"id":"rdg-"+args.slug,
      "identitySpace":args.identity_space,"rootRequirementId":args.root_id,
      "planningScale":"module","title":args.title,"revision":1,"catalogSlug":args.slug,"presentation":{"usage":"working"},
      "nodes":[{"id":args.root_id,"kind":"requirement","title":args.root_title,"status":"active","qrpe":[]}],
      "edges":[],"events":[],"collections":[]}
    WRITER.validate(graph)
    relative=f"workspaces/{args.slug}/graph.json"
    # Validate the complete catalog and identity rules before any persistent write.
    INDEX.build_catalog({relative:graph})
    if args.dry_run:
        print("DRY_RUN_NEW_WORKSPACE "+json.dumps({"file":relative,"graph":graph},ensure_ascii=False))
        return
    dir=GRAPHS/"workspaces"/args.slug
    dir.mkdir(parents=False,exist_ok=False)
    file=dir/"graph.json"
    try:
        with file.open("x",encoding="utf-8") as out:
            json.dump(graph,out,ensure_ascii=False,indent=2)
            out.write("\n");out.flush();os.fsync(out.fileno())
        INDEX.rebuild_index()
    except Exception:
        if file.exists():file.unlink()
        dir.rmdir()
        raise
    print("NEW_WORKSPACE_CREATED "+relative+" revision=1 decisions=0")

if __name__=="__main__":
    try:main()
    except (ValueError,OSError) as exc:
        print("ERROR: "+str(exc),file=sys.stderr);sys.exit(2)
