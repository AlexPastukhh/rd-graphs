/* Shared data/command layer; embedded into the userscript by build-rdg-layout.py. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.RDGLayoutCore=api;
})(globalThis,function(){
  'use strict';
  const clone=x=>JSON.parse(JSON.stringify(x));
  const object=x=>x&&typeof x==='object'&&!Array.isArray(x);
  const key=k=>typeof k==='string'&&k.length>0&&k.length<=500&&!['__proto__','prototype','constructor'].includes(k)&&!/[\x00-\x1f]/.test(k);
  const empty=()=>({schemaVersion:1,revision:0,layouts:{}});
  function validate(doc){
    if(!object(doc)||doc.schemaVersion!==1||!Number.isSafeInteger(doc.revision)||doc.revision<0||!object(doc.layouts))throw Error('Некорректный документ расположений');
    for(const [graphKey,layout] of Object.entries(doc.layouts)){
      if(!key(graphKey)||!object(layout)||!object(layout.positions))throw Error('Некорректный ключ графа/расположение');
      if(Object.keys(layout.positions).length>2000)throw Error('Слишком много координат');
      for(const [id,p] of Object.entries(layout.positions)){
        if(!key(id)||!object(p)||!Number.isFinite(p.x)||!Number.isFinite(p.y)||Math.abs(p.x)>1000000||Math.abs(p.y)>1000000)throw Error('Некорректные координаты: '+id);
      }
    }
    return clone(doc);
  }
  function graphKey(identitySpace,slug,rootRequirementId){
    if(!key(identitySpace)||!key(slug)||rootRequirementId!==undefined&&!key(rootRequirementId))throw Error('Для расположения нужны identitySpace, slug и допустимая корневая R');
    return JSON.stringify(rootRequirementId===undefined?[identitySpace,slug]:[identitySpace,slug,rootRequirementId]);
  }
  function apply(document,commands){
    const doc=validate(document);
    for(const cmd of Array.isArray(commands)?commands:[commands]){
      if(!object(cmd)||!key(cmd.graphKey))throw Error('Команда без graphKey');
      if(cmd.type==='set_positions'){
        if(!object(cmd.positions))throw Error('Нет positions');
        const current=doc.layouts[cmd.graphKey]?.positions||{};
        for(const id of Object.keys(cmd.positions))if(!key(id))throw Error('Некорректный ID');
        doc.layouts[cmd.graphKey]={positions:{...current,...clone(cmd.positions)}};
      }else if(cmd.type==='clear_layout')delete doc.layouts[cmd.graphKey];
      else throw Error('Неизвестная команда расположения: '+cmd.type);
    }
    return validate(doc);
  }
  function commit(document,expectedRevision){
    const doc=validate(document);
    if(doc.revision!==expectedRevision)throw Error('Конфликт ревизии расположений');
    doc.revision++;return validate(doc);
  }
  return Object.freeze({empty,validate,graphKey,apply,commit});
});
