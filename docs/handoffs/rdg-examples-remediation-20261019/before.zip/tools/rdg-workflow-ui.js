/* Local manual workflow controller. Same Graph/Plan writers, no optimistic facts. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else{
    root.RDGWorkflowUI=api;
    const host=document.getElementById('rdg-viewer-root');
    if(host&&root.RDG_LOCAL_WORKFLOW){
      const base=new URL('./',location.href),session=root.RDG_SESSION;
      const request=async(path,body)=>{
        const response=await fetch(new URL(path,base),{method:body?'POST':'GET',credentials:'omit',
          redirect:'error',headers:{'X-RDG-Session':session,...(body?{'Content-Type':'application/json'}:{})},
          ...(body?{body:JSON.stringify(body)}:{})});
        const result=await response.json();
        if(!response.ok){const error=Error(result.error||'Запрос отклонён');error.definite=result.definite!==false;throw error;}
        return result;
      };
      const ui=api.mount(host.rdgWorkflow.attach(),{read:()=>request('state'),write:r=>request('command',r)},
        {document,graphContainer:host.rdgWorkflow.graphEditor(),onGraph:(g,v)=>host.rdgWorkflow.loadGraph(g,v),onNavigate:(ref,v)=>host.rdgWorkflow.openDeclaration(ref,v)});
      root.RDG_LOCAL_EDITOR=ui;void ui.refresh();
    }
  }
})(globalThis,function(){
  'use strict';
  function fileTransport(directory,options={}){
    const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
    let report=options.onStatus||(()=>{});
    const readJson=async name=>JSON.parse(await (await directory.getFileHandle(name)).getFile().then(f=>f.text()));
    const writeJson=async(name,value)=>{
      const file=await directory.getFileHandle(name,{create:true}),writer=await file.createWritable();
      await writer.write(JSON.stringify(value));await writer.close();
    };
    const checkDescriptor=async()=>{
      let descriptor;
      try{descriptor=await readJson('session.json');}
      catch(e){
        if(e.name==='NotFoundError')throw Error('В этой папке нет session.json. Выберите папку session, созданную локальным Helper.');
        throw e;
      }
      if(!descriptor||descriptor.schemaVersion!==1||descriptor.kind!=='rdg-local-manual-session')
        throw Error('Это не папка сессии RDG. Выберите папку session, созданную локальным Helper.');
      if(descriptor.active===false)throw Error('Сессия Helper завершена. Запустите новую сессию и подключите её папку.');
      if(descriptor.active!==true||typeof descriptor.session!=='string'||!descriptor.session)
        throw Error('Файл session.json повреждён или неполон. Запустите новую сессию Helper и подключите её папку.');
      return descriptor;
    };
    async function exchange(kind,body){
      let queued=false;
      try{
        report('Проверяю папку сессии…');
        const descriptor=await checkDescriptor();
        const random=typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
        const id='io-'+random,request='request-'+id+'.json',ready='request-'+id+'.ready',response='response-'+id+'.json';
        report('Записываю запрос в папку сессии… Если браузер просит доступ к записи, подтвердите его для выбранной папки session.');
        await writeJson(request,{session:descriptor.session,kind,body});
        // A failed close of the ready marker may still have queued the request.
        queued=true;await writeJson(ready,{ready:true});
        const started=Date.now(),timeout=options.timeoutMs??(kind==='state'?10000:45000);
        let checked=started,shown=-1;
        while(Date.now()-started<timeout){
          let result;
          try{result=await readJson(response);}
          catch(e){if(e.name!=='NotFoundError')throw e;}
          if(result){
            for(const name of [ready,request,response]){
              try{await directory.removeEntry(name);}catch{/* cleanup never changes accepted outcome */}
            }
            if(!result.ok){const error=Error(result.error||'Запрос отклонён');error.definite=result.definite!==false;throw error;}
            return result.result;
          }
          const seconds=Math.floor((Date.now()-started)/1000);
          if(seconds!==shown){shown=seconds;report('Ожидаю ответ локального Helper… '+seconds+' с.');}
          if(Date.now()-checked>=1000){
            const current=await checkDescriptor();checked=Date.now();
            if(current.session!==descriptor.session)throw Error('В папке уже другая сессия Helper. Подключите папку заново.');
          }
          await pause(options.pollMs??150);
        }
        throw Error(kind==='state'?
          'Helper не ответил за '+Math.round(timeout/1000)+' с. Проверьте, что он запущен и выбрана его папка session. Затем нажмите «Обновить» или подключите новую папку.':
          'Helper не ответил. Исход записи неизвестен. Проверьте Helper, обновите данные и повторите тот же запрос.');
      }catch(e){
        if(e.name==='NotAllowedError'||e.name==='SecurityError'){
          const error=Error('Нет доступа к папке сессии. Подключите её заново и разрешите чтение и запись.');
          error.definite=!queued||kind==='state';throw error;
        }
        if(!queued||kind==='state')e.definite=true;
        throw e;
      }
    }
    return {read:()=>exchange('state',null),write:body=>exchange('command',body),
      setStatus:callback=>{report=callback;}};
  }
  function declarationFor(view,reference){
    const graphs=view?.sources?.graphs||{};
    let ref={...reference},node,graph,kind=null;const seen=new Set();
    for(;;){
      const key=[ref.graphFile,ref.identitySpace,ref.nodeId].join('|');
      if(seen.has(key))throw Error('Цикл ссылок на объявление узла');seen.add(key);
      graph=graphs[ref.graphFile];node=graph?.nodes.find(n=>n.id===ref.nodeId);
      if(!graph||graph.identitySpace!==ref.identitySpace||!node)throw Error('Граф объявления недоступен в подключённой сессии');
      if(kind&&node.kind!==kind)throw Error('Тип узла владельца не совпадает с проекцией');kind=node.kind;
      if(!node.projectionOf)break;
      const owner=view.sources.completion?.[ref.graphFile]?.[ref.nodeId]?.ownerRef;
      if(!owner||owner.identitySpace!==ref.identitySpace)throw Error('Владелец проекции не подтверждён; переход к личному графу не выполняется');
      ref={...owner};
    }
    const root=graph.rootRequirementId||graph.nodes.find(n=>n.kind==='requirement')?.id;
    let contextRootId=root;
    if(node.kind==='requirement'&&node.id!==root){
      const introductions=graph.edges.filter(e=>e.type==='INTRODUCES'&&e.to===node.id&&!e.archived);
      const contexts=introductions.flatMap(e=>e.parent?[e.parent]:graph.edges.filter(d=>
        ['DRIVES','OPTION_FOR'].includes(d.type)&&d.to===e.from&&!d.archived).map(d=>d.from));
      contextRootId=contexts.find(id=>graph.nodes.some(n=>n.id===id&&n.kind==='requirement'));
      if(!contextRootId)throw Error('Не найден контекст первого объявления цели');
    }else if(node.kind==='action'){
      contextRootId=graph.edges.find(e=>['DRIVES','OPTION_FOR'].includes(e.type)&&e.to===node.id&&!e.archived)?.from;
      if(!contextRootId)throw Error('Не найдена цель, для которой объявлен Action');
    }
    return {ref,graph,node,contextRootId};
  }
  function mount(container,transport,options={}){
    const doc=options.document||document,fields={},buttons={};
    let view=null,busy=false,pending=null,activeId=null;const cardControls=[];let graphStatus=null,graphRetry=null;
    const make=(tag,text,parent)=>{const x=doc.createElement(tag);if(text!==undefined)x.textContent=text;
      if(parent)parent.appendChild(x);return x;};
    const toolbar=make('div',undefined,container);toolbar.classList.add('wf-toolbar');
    const heading=make('h3','Данные плана',toolbar);
    const refresh=make('button','Обновить',toolbar);
    const jump=make('button','Перейти к плану ↓',toolbar);jump.classList.add('wf-jump-plan');
    jump.disabled=true;buttons.jumpPlan=jump;let firstPlannedCard=null;
    jump.onclick=()=>{
      if(!firstPlannedCard)return;
      const scrollRoot=container.closest?.('#workflow-page');
      const behavior=typeof matchMedia==='function'&&matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth';
      if(scrollRoot?.scrollTo){
        const top=firstPlannedCard.getBoundingClientRect().top-scrollRoot.getBoundingClientRect().top+
          scrollRoot.scrollTop-toolbar.getBoundingClientRect().height-16;
        scrollRoot.scrollTo({top,behavior});
      }else firstPlannedCard.scrollIntoView?.({block:'start',behavior});
      firstPlannedCard.focus?.({preventScroll:true});
    };
    const status=make('div','Данные ещё не загружены. Нажмите «Обновить».',toolbar);status.classList.add('wf-status');status.setAttribute('role','status');
    const editor=make('details',undefined,container);editor.classList.add('wf-editor');editor.hidden=true;
    make('summary','Разместить из графа',editor);
    make('h3','Размещение цели или Action',editor);
    const grid=make('div',undefined,container);grid.classList.add('wf-grid');grid.classList.add('wf-timeline');grid.hidden=true;
    if(transport.setStatus)transport.setStatus(message=>{status.textContent=message;syncStatus();});
    const history=make('section',undefined,grid),future=make('section',undefined,grid);
    history.classList.add('wf-history');history.setAttribute('aria-label','История');
    future.classList.add('wf-future');future.setAttribute('aria-label','План во времени');
    let fieldParent=editor;
    function field(name,label,tag='input',type='text'){
      const l=make('label',label,fieldParent),x=make(tag,undefined,l);
      if(tag==='input')x.type=type;x.value='';
      x.setAttribute('aria-label',label);fields[name]=x;return x;
    }
    field('graph','Граф с существующей целью или Action','select');
    const target=field('target','Цель или Action','select');
    const details=make('p','',editor);
    field('note','Основание изменения или результат выполнения','textarea');
    field('placement','Сохранённое размещение','select');
    field('at','Дата начала не ранее','input','date');
    field('after','После размещённой цели или Action','select');
    const placementDetails=make('p',undefined,editor);
    const planControls=make('div',undefined,editor);
    const graphEditor=make('details',undefined,options.graphContainer);
    make('summary','Редактировать граф / записать результат',graphEditor);
    graphEditor.open=!!options.graphContainer;
    graphStatus=make('div','',graphEditor);graphStatus.setAttribute('role','status');
    graphRetry=make('button','Повторить тот же запрос',graphEditor);graphRetry.onclick=()=>send(pending);
    function syncStatus(){if(graphStatus){graphStatus.textContent=status.textContent;graphStatus.classList.toggle('wf-error',!!status.classList.contains?.('wf-error'));}if(graphRetry){graphRetry.hidden=!pending;graphRetry.disabled=busy||!pending;}}
    make('p','Изменения в подключённом графе. Размещение во времени выполняется на вкладке плана.',graphEditor);
    const graphTarget=make('select',undefined,make('label','Сущность графа',graphEditor));
    graphTarget.setAttribute('aria-label','Сущность редактируемого графа');
    const graphNote=make('textarea',undefined,make('label','Основание изменения или результат',graphEditor));
    graphNote.setAttribute('aria-label','Основание изменения графа');
    graphNote.oninput=()=>{fields.note.value=graphNote.value;};
    fields.note.oninput=()=>{graphNote.value=fields.note.value;};
    fieldParent=graphEditor;
    field('title','Название');
    field('actionType','Тип нового Action','select');
    field('recommended','Когда способ подходит — по одному случаю на строку','textarea');
    field('contraindicated','Когда способ не подходит','textarea');
    field('childRole','Роль новой дочерней R','select');
    field('qrpe','Новая запись QRPE');
    const childBox=make('div',undefined,graphEditor);make('p','При отзыве укажите судьбу каждой введённой R. Изменения примет только штатный writer.',childBox);
    const dispositionFields=[];
    const controls=make('div',undefined,graphEditor);
    function button(name,title,action){
      const b=make('button',title,['place','unplace'].includes(name)?planControls:controls);b.onclick=()=>run(action);buttons[name]=b;return b;
    }
    button('add','Создать вариант Action','add_action');button('title','Изменить название','edit_title');
    button('canon','Записать канон','edit_canon');button('requirement','Добавить дочернюю R','prepare_requirement');
    button('qrpe','Добавить QRPE','add_qrpe');button('select','Выбрать Action','select');
    button('complete','Записать выполнение / достижение','complete');button('withdraw','Отозвать выполненный Action','withdraw');
    button('place','Разместить / изменить место','place');button('unplace','Снять размещение','unplace');
    buttons.retry=make('button','Повторить тот же запрос',container);buttons.retry.onclick=()=>send(pending);
    buttons.refresh=refresh;refresh.onclick=()=>refreshView();
    function optionsFor(select,items,value){
      select.replaceChildren();for(const [id,title] of items){const o=make('option',title,select);o.value=id;}
      select.value=items.some(x=>x[0]===value)?value:(items[0]?.[0]||'');
    }
    optionsFor(fields.actionType,[['general','Обычный'],['decomposition','Выделение подцелей']],'general');
    optionsFor(fields.childRole,[['subgoal','Часть разбиения родительской цели'],['method_correctness','Нужно для корректного выполнения Action']],'subgoal');
    function selectedFile(){return fields.graph.value||view?.graphFile;}
    function graph(){return view?.sources.graphs[selectedFile()];}
    function fillTargets(id=activeId){
      optionsFor(target,(graph()?.nodes||[]).filter(n=>['action','requirement'].includes(n.kind)).map(n=>[n.id,n.title+' · '+n.kind+' · '+(n.status||'active')]),id);
      focus();
    }
    fields.graph.onchange=()=>fillTargets(null);
    graphTarget.onchange=()=>{fields.graph.value=view.graphFile;fillTargets(graphTarget.value);};
    function selected(){return graph()?.nodes.find(n=>n.id===target.value);}
    function updateControls(){
      const n=selected(),perms=view?.permissions||[],graphWrite=p=>selectedFile()===view?.graphFile&&(perms.includes('graph.write')||perms.includes('graph.'+p));
      const protectedGraph=view&&Object.values(view.sources.graphs).some(g=>g.nodes.some(n=>n.reconsiderationPolicy?.mode==='protected'));
      jump.disabled=!view||!firstPlannedCard;
      const locked=busy||!!pending||!view,own=n&&!n.projectionOf,executed=graph()?.events.some(e=>e.type==='action_executed'&&e.targetId===n?.id);
      const policy=protectedGraph||!own;
      const canDrive=own||n?.id===view?.continuationRootId;
      buttons.add.disabled=locked||protectedGraph||!canDrive||n?.kind!=='requirement'||!graphWrite('add_action');
      buttons.title.disabled=locked||policy||!graphWrite('graph_edit.edit_node');
      buttons.canon.disabled=locked||policy||n?.kind!=='action'||!graphWrite('graph_edit.edit_node');
      buttons.requirement.disabled=locked||policy||n?.kind!=='action'||!graphWrite('graph_edit.prepare_action_requirement');
      buttons.qrpe.disabled=locked||policy||!graphWrite('append_qrpe');
      buttons.select.disabled=locked||policy||n?.kind!=='action'||n.status!=='candidate'||!graphWrite('select_action');
      buttons.complete.disabled=locked||policy||executed||n?.status==='superseded'||
        !graphWrite(n?.kind==='action'?'record_action_execution':'record_requirement_achievement');
      buttons.withdraw.disabled=locked||policy||n?.kind!=='action'||n.status!=='selected'||!executed||!graphWrite('withdraw_action');
      buttons.place.disabled=locked||!n||!perms.includes('plan.edit')||placementState().complex;
      buttons.unplace.disabled=locked||!fields.placement.value||!perms.includes('plan.edit');
      for(const control of cardControls)control.button.disabled=locked||!perms.includes('plan.edit')||!control.allowed;
      buttons.retry.hidden=!pending;buttons.retry.disabled=busy||!pending;buttons.refresh.disabled=busy;
      syncStatus();
      if(options.onStateChange)options.onStateChange({busy,pending:!!pending,ready:!!view});
    }
    function placementState(){
      const plan=view?.sources.plan,chosen=plan?.steps.find(s=>s.id===fields.placement.value);
      const rules=chosen?(plan.timeConstraints||[]).filter(r=>r.stepId===chosen.id):[];
      const starts=rules.filter(r=>r.type==='notBefore');
      const incoming=chosen?(plan.sequence||[]).filter(e=>e.after===chosen.id):[];
      return {chosen,rules,starts,incoming,complex:starts.length>1||incoming.length>1||
        starts.some(r=>!/^\d{4}-\d{2}-\d{2}$/.test(r.at))};
    }
    function loadPlacement(){
      const p=placementState();
      fields.at.value=p.starts.length===1&&!p.complex?p.starts[0].at:'';
      const steps=view.sources.plan.steps.filter(s=>s.id!==p.chosen?.id);
      optionsFor(fields.after,[['','Без порядка'],...steps.map(s=>[s.id,s.title])],
        p.incoming.length===1?p.incoming[0].before:'');
      placementDetails.textContent=p.complex?'Сложное размещение: измените его через полный API. Сохранённые правила не будут обрезаны.':
        p.rules.map(r=>(r.type==='deadline'?'Срок до ':'Начать не ранее ')+r.at+' ['+r.strength+']').join('; ')+
        (p.incoming[0]?.minDelayDays!==undefined?' · Интервал после предшественника: '+p.incoming[0].minDelayDays+' дн.':'');
      updateControls();
    }
    function focus(){
      const n=selected();if(!n)return;activeId=n.id;
      if(selectedFile()===view.graphFile)graphTarget.value=n.id;
      graphNote.value=fields.note.value;
      fields.title.value=n.title;
      fields.recommended.value=(n.canonBlock?.recommended||[]).map(c=>c.text).join('\n');
      fields.contraindicated.value=(n.canonBlock?.contraindicated||[]).map(c=>c.text).join('\n');
      const completion=view.sources.completion?.[selectedFile()]?.[n.id];
      details.textContent=n.id+' · '+n.kind+' · '+(n.status||'active')+
        (completion?.complete&&!completion.historyPending?' · выполнено':completion?.historyPending?' · результат ожидает записи writer':' · не завершено')+
        (n.projectionOf&&completion?.ownerRef?' · владелец: '+completion.ownerRef.graphFile:'')+
        (n.qrpe?.length?'\nQRPE: '+n.qrpe.map(q=>'['+q.status+'] '+q.text).join('; '):'')+
        (n.reconsiderationPolicy?.mode==='protected'?' · защищено: ручная запись недоступна':'');
      const placements=view.sources.plan.steps.filter(s=>{
        const ref=s.actionRef||s.requirementRef;
        return ref?.nodeId===n.id&&ref.graphFile===selectedFile()&&ref.identitySpace===graph().identitySpace;
      });
      optionsFor(fields.placement,[['','Выберите размещение'],...placements.map(s=>[s.id,s.title+' · '+s.id])],
        placements.length===1?placements[0].id:'');
      loadPlacement();
      childBox.replaceChildren();dispositionFields.length=0;
      for(const e of graph().edges.filter(e=>e.type==='INTRODUCES'&&e.from===n.id&&!e.archived)){
        const row=make('label',graph().nodes.find(n=>n.id===e.to)?.title||e.to,childBox);
        const select=make('select',undefined,row);optionsFor(select,[['','Выберите судьбу R'],['retain_supported','Сохранить: поддержана другим выбранным Action'],['deactivate','Деактивировать: нет других зависимостей']],'');
        dispositionFields.push({id:e.to,select});
      }
      updateControls();
    }
    target.onchange=focus;fields.placement.onchange=loadPlacement;
    function reference(file,id){return {graphFile:file,identitySpace:view.sources.graphs[file]?.identitySpace,nodeId:id};}
    function nodeAt(ref){return view.sources.graphs[ref.graphFile]?.identitySpace===ref.identitySpace?
      view.sources.graphs[ref.graphFile].nodes.find(n=>n.id===ref.nodeId):null;}
    function editPlacement(ref,stepId){
      if(!view.sources.graphs[ref.graphFile]||!nodeAt(ref))return;
      if(ref.graphFile!==view.graphFile&&!view.capabilities?.includes('plan.place.from-read-sources')){status.textContent='Для размещения из другого графа обновите локальный Helper.';return;}
      fields.graph.value=ref.graphFile;fillTargets(ref.nodeId);
      if(stepId){fields.placement.value=stepId;loadPlacement();}
      editor.open=true;editor.scrollIntoView?.({block:'nearest',behavior:'smooth'});
    }
    async function navigate(ref){
      try{
        const origin=declarationFor(view,ref);
        if(origin.ref.graphFile===view.graphFile||view.capabilities?.includes('plan.place.from-read-sources')){fields.graph.value=origin.ref.graphFile;fillTargets(origin.ref.nodeId);}
        if(!options.onNavigate)throw Error('Переход доступен в подключённом Viewer');
        await options.onNavigate(origin.ref,view);
      }catch(e){status.textContent='Не удалось открыть объявление: '+e.message;status.classList.add('wf-error');}
    }
    const refKey=ref=>[ref.graphFile,ref.identitySpace,ref.nodeId].join('|');
    function entityKey(ref){try{return refKey(declarationFor(view,ref).ref);}catch{return refKey(ref);}}
    function material(card,node,historical=false){
      if(node.kind==='action'){
        const canon=make('details',undefined,card);canon.classList.add('wf-canon');
        canon.open=!historical;
        const positive=node.canonBlock?.recommended||[],negative=node.canonBlock?.contraindicated||[];
        make('summary',(historical?'Канон из графа':'Канон')+' (+'+positive.length+'/−'+negative.length+')',canon);
        for(const [label,rows] of [['Когда подходит',positive],['Когда не подходит',negative]]){
          const block=make('div',undefined,canon);block.classList.add('wf-canon-case');
          block.setAttribute('data-valence',label==='Когда подходит'?'positive':'negative');
          make('strong',label,block);const ul=make('ul',undefined,block);
          if(!rows.length)make('li','Не заполнено',ul);
          for(const c of rows)make('li',c.text,ul);
        }
      }
      const issues=node.qrpe||[],open=issues.filter(q=>!['closed','resolved','invalidated'].includes(q.status));
      const qrpe=make('details',undefined,card);qrpe.classList.add('wf-qrpe');qrpe.open=!historical&&open.length>0;
      make('summary',(historical?'QRPE из графа':'QRPE')+' · '+open.length+' открыто / '+issues.length,qrpe);
      if(!issues.length)make('p','Записей QRPE нет.',qrpe);
      for(const q of issues)make('p','['+q.status+'] '+q.text,qrpe);
      if(historical&&open.length){const warning=make('p',open[0].text,card);warning.classList.add('wf-qrpe-preview');}
    }
    function card(parent,ref,{row=null,variant=false,historical=false,event=null,title=null,variants=true}={}){
      const local=nodeAt(ref);let origin=null;try{origin=declarationFor(view,ref);}catch{}
      const n=origin?.node||local;
      if(!n){make('p','Узел недоступен: '+ref.nodeId,parent);return;}
      const article=make('article',undefined,parent);article.classList.add('wf-card');article.classList.add(n.kind);
      article.setAttribute('data-node-id',n.id);article.setAttribute('data-graph-file',ref.graphFile);
      article.setAttribute('data-status',n.status||'active');
      article.setAttribute('data-placement-id',row?.stepId||'');article.setAttribute('data-context',variant?'variant':historical?'history':'placement');
      const kind=n.kind==='action'?'Action / способ':'R / цель';
      const state={selected:'выбран',candidate:'кандидат',potential:'предварительная',active:'активная',superseded:'пересмотрен',inactive:'неактивная'}[n.status]||n.status||'';
      const placements=view.future.filter(r=>entityKey(r.graphRef||reference(view.graphFile,r.nodeId))===entityKey(ref));
      const isPlaced=placements.length>0;
      const meta=make('small',undefined,article);meta.classList.add('wf-card-meta');
      make('span',kind,meta).classList.add('wf-kind-badge');
      if(state)make('span',historical?'В графе сейчас: '+state:state,meta).classList.add('wf-state-badge');
      if(variant)make('span',isPlaced?'размещён отдельно':'вариант, не размещён',meta);
      if(event){
        article.setAttribute('data-event-kind',event.kind);
        make('span',eventLabels[event.kind]||event.kind,meta).classList.add('wf-event-badge');
        eventTime(article,event.recordedAt);
      }
      const open=make('button',title||n.title,article);open.classList.add('wf-card-title');open.onclick=()=>navigate(ref);
      open.disabled=!origin||!options.onNavigate;open.title=origin?'Открыть место объявления в графе':'Объявление недоступно в подключённой сессии';
      make('small',n.id,article);
      if(n.kind==='action'&&origin&&!variant){
        const goalRef={...origin.ref,nodeId:origin.contextRootId},goal=nodeAt(goalRef);
        if(goal){
          const context=make('p','Для цели: ',article),link=make('button',goal.title,context);link.classList.add('wf-card-goal');
          link.onclick=()=>navigate(goalRef);link.disabled=!options.onNavigate;
          if(!view.future.some(r=>entityKey(r.graphRef||reference(view.graphFile,r.nodeId))===entityKey(goalRef)))
            make('small','Цель показана для контекста и не размещена.',context);
        }
      }
      if(row){
        for(const rule of row.timeConstraints||[])make('p',(rule.type==='deadline'?'Срок до ':'Начать не ранее ')+rule.at+' ['+rule.strength+']',article);
        for(const link of row.sequence||[]){
          const sid=link.after===row.stepId?link.before:link.after,step=view.sources.plan.steps.find(s=>s.id===sid);
          const targetRef=step?.actionRef||step?.requirementRef,other=targetRef&&nodeAt(targetRef);
          make('p',(link.after===row.stepId?'После: ':'Перед: ')+(other?.title||step?.title||sid)+
            (link.minDelayDays!==undefined?' · интервал '+link.minDelayDays+' дн.':''),article);
        }
      }
      if(event?.note){const note=make('p',event.note,article);note.classList.add('wf-result-note');}
      if(origin||!n.projectionOf)material(article,n,historical);
      else make('p','Канон и QRPE владельца недоступны в этой сессии.',article);
      if(historical){
        const link=make('button','Открыть в графе ↗',article);link.classList.add('wf-open-graph');
        link.onclick=()=>navigate(ref);link.disabled=!origin||!options.onNavigate;
        link.title=open.title;
      }
      if(!historical){
        const placement=row||(variant?placements[0]:null),placementRef=placement?.graphRef||ref;
        const edit=make('button',variant&&!isPlaced?'Разместить':variant&&placements.length>1?'К первому размещению':'Изменить размещение',article);
        edit.disabled=busy||!!pending||!(view.permissions||[]).includes('plan.edit');
        edit.onclick=()=>editPlacement(placementRef,placement?.stepId);edit.classList.add('wf-card-place');
        const allowed=placementRef.graphFile===view.graphFile||!!view.capabilities?.includes('plan.place.from-read-sources');
        cardControls.push({button:edit,allowed});if(!allowed){edit.disabled=true;edit.title='Для размещения из другого графа обновите локальный Helper';}
      }
      if(variants&&n.kind==='requirement'&&origin){
        const actions=[],seenActions=new Set(),goalKey=refKey(origin.ref);
        for(const [file,source] of Object.entries(view.sources.graphs)){
          if(source.identitySpace!==origin.ref.identitySpace)continue;
          const goalIds=source.nodes.filter(r=>r.kind==='requirement'&&entityKey(reference(file,r.id))===goalKey).map(r=>r.id);
          for(const edge of source.edges.filter(e=>['DRIVES','OPTION_FOR'].includes(e.type)&&goalIds.includes(e.from)&&!e.archived)){
            const action=source.nodes.find(a=>a.id===edge.to&&a.kind==='action');
            if(!action||action.active===false||['superseded','rejected','inactive'].includes(action.status))continue;
            const actionRef=reference(file,action.id),key=entityKey(actionRef);
            if(!seenActions.has(key)){seenActions.add(key);actions.push({node:action,ref:actionRef});}
          }
        }
        if(actions.length){
          const chain=make('div',undefined,article);chain.classList.add('wf-variants');
          make('p','Варианты Action для этой цели. В плане — только явно размещённые.',chain);
          const list=make('div',undefined,chain);list.classList.add('wf-variant-list');
          for(const action of actions)card(list,action.ref,{variant:true,historical,variants:false});
        }
      }
      return article;
    }
    const eventLabels={graph_saved:'Изменён граф',action_executed:'Выполнен Action',
      requirement_achieved:'Достигнута цель',action_withdrawn:'Отозван Action'};
    function eventTime(parent,at){
      const time=make('time',undefined,parent);time.classList.add('wf-event-time');
      const value=at&&new Date(at);
      time.textContent=value&&!Number.isNaN(value.getTime())?
        'Записано '+value.toLocaleString('ru-RU',{dateStyle:'medium',timeStyle:'short'}):'Время записи неизвестно';
      if(at){time.setAttribute('datetime',at);time.title=at;}
    }
    function renderPlan(){
      cardControls.length=0;firstPlannedCard=null;
      history.replaceChildren();make('h3','История',history);
      if(!view.history.length)make('p','Записей ещё нет.',history);
      let lastDay=null;
      for(const r of view.history){
        const date=r.recordedAt&&new Date(r.recordedAt),valid=date&&!Number.isNaN(date.getTime());
        const day=valid?date.toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'}):'Без времени записи';
        if(day!==lastDay){const divider=make('h4',day,history);divider.classList.add('wf-day');lastDay=day;}
        const ref=reference(r.graphFile||view.graphFile,r.targetId),node=nodeAt(ref);
        if(node&&['action','requirement'].includes(node.kind)){
          card(history,ref,{historical:true,event:r,title:r.title||node.title,variants:false});
        }else{
          const event=make('article',undefined,history);event.classList.add('wf-history-event');event.classList.add('wf-card');
          event.setAttribute('data-context','history');event.setAttribute('data-event-kind',r.kind);
          make('strong',eventLabels[r.kind]||r.kind,event);eventTime(event,r.recordedAt);
          make('p',r.summary||r.title||r.note||'Запись об изменении графа.',event);
          const links=make('div',undefined,event);links.classList.add('wf-changed-nodes');
          for(const id of r.changed?.nodes||[]){
            const changedRef=reference(r.graphFile||view.graphFile,id),changed=nodeAt(changedRef);
            if(!changed||!['action','requirement'].includes(changed.kind))continue;
            let origin;try{origin=declarationFor(view,changedRef);}catch{}
            const link=make('button',changed.title+' ↗',links);link.classList.add('wf-open-graph');
            link.onclick=()=>navigate(changedRef);link.disabled=!origin||!options.onNavigate;
          }
          if(r.note&&r.note!==(r.summary||r.title)){const note=make('p',r.note,event);note.classList.add('wf-result-note');}
          if(r.targetId&&!node)make('small','Узел '+r.targetId+' недоступен в подключённом графе.',event);
        }
      }
      future.replaceChildren();
      const boundary=make('header',undefined,future);boundary.classList.add('wf-plan-boundary');
      make('small','Конец истории · далее запланированное',boundary);
      make('h3','План во времени',boundary);
      make('p',view.future.length?'Явно размещённые цели и Actions · '+view.future.length:
        'Пока нет запланированных целей или Actions.',boundary);
      for(const row of view.future){
        const article=card(future,row.graphRef||reference(view.graphFile,row.nodeId),{row});
        if(!firstPlannedCard&&article){firstPlannedCard=article;article.setAttribute('tabindex','-1');}
      }
      if(view.unresolved.length)make('p','Не разрешены ссылки: '+view.unresolved.map(r=>r.nodeId).join(', '),future);
      jump.disabled=!firstPlannedCard;
      jump.title=firstPlannedCard?'Перейти к первому запланированному блоку':'В плане пока нет доступных блоков';
    }
    async function install(next){
      view=next;
      optionsFor(fields.graph,Object.entries(view.sources.graphs).filter(([file,g])=>g.identitySpace===view.sources.graphs[view.graphFile].identitySpace&&(file===view.graphFile||view.capabilities?.includes('plan.place.from-read-sources')))
        .map(([file,g])=>[file,(g.title||file)+' · '+file]),fields.graph.value||view.graphFile);
      optionsFor(graphTarget,view.sources.graphs[view.graphFile].nodes.filter(n=>['action','requirement'].includes(n.kind)).map(n=>[n.id,n.title+' · '+n.id]),activeId);
      fillTargets();renderPlan();
      heading.textContent=view.title;grid.hidden=false;editor.hidden=false;
      if(options.onGraph)await options.onGraph(view.sources.graphs[view.graphFile],view);
    }
    async function refreshView(){
      if(busy)return;busy=true;updateControls();status.textContent='Запрашиваю данные локального Helper…';syncStatus();
      try{await install(await transport.read());status.textContent='Данные перечитаны.';status.classList.remove('wf-error');}
      catch(e){status.textContent='Не удалось загрузить данные: '+e.message+(view?' Показаны ранее загруженные данные.':'');status.classList.add('wf-error');}
      finally{busy=false;updateControls();}
    }
    function request(action){
      const n=selected();if(!n)throw Error('Выберите сущность графа');
      const random=typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
      const req={action,transactionId:'ui-'+random,nodeId:n.id,note:fields.note.value,
        expectedGraphRevision:graph().revision,expectedPlanRevision:view.sources.plan.revision};
      if(['add_action','edit_title','prepare_requirement'].includes(action))req.title=fields.title.value;
      if(['add_action','edit_canon'].includes(action)){req.recommended=fields.recommended.value;req.contraindicated=fields.contraindicated.value;}
      if(action==='add_action')req.actionType=fields.actionType.value;
      if(action==='prepare_requirement')req.childRole=fields.childRole.value;
      if(action==='add_qrpe')req.title=fields.qrpe.value;
      if(action==='place'){if(selectedFile()!==view.graphFile)req.graphFile=selectedFile();req.at=fields.at.value;req.afterStepId=fields.after.value;req.stepId=fields.placement.value;}
      if(action==='unplace')req.stepId=fields.placement.value;
      if(action==='withdraw'){
        req.dispositions=dispositionFields.map(d=>{
          if(!d.select.value)throw Error('Укажите судьбу каждой дочерней R');
          const result={requirementId:d.id,effect:d.select.value,reason:fields.note.value};
          if(d.select.value==='deactivate')result.downstreamScope='single_graph_verified';
          else result.supportingActionIds=graph().edges.filter(e=>e.type==='INTRODUCES'&&e.to===d.id&&e.from!==n.id&&!e.archived&&
            graph().nodes.some(n=>n.id===e.from&&n.status==='selected')).map(e=>e.from);
          return result;
        });
      }
      return req;
    }
    async function run(action){
      if(busy)return;
      if(!['place','unplace'].includes(action)&&selectedFile()!==view?.graphFile){status.textContent='Изменять можно только подключённый граф. Выберите его сущность на вкладке графа.';return;}
      if(pending){status.textContent='Сначала проверьте исход предыдущего запроса или повторите тот же запрос.';return;}
      try{return await send(request(action));}
      catch(e){status.textContent=e.message;status.classList.add('wf-error');syncStatus();}
    }
    async function send(req){
      if(busy||!req)return;busy=true;pending=req;let accepted=false;updateControls();status.textContent='Сохранение…';syncStatus();
      try{
        const result=await transport.write(req);
        if(!result.saved)throw Error('Writer не подтвердил сохранение');
        pending=null;accepted=true;
        if(req.action==='add_action')activeId='A-'+req.transactionId;
        if(req.action==='prepare_requirement')activeId='R-'+req.transactionId;
        if(result.view)await install(result.view);
        status.textContent=result.refreshError?'Запись сохранена, но перечитать данные не удалось: '+result.refreshError:
          result.replayed?'Предыдущая запись подтверждена; повторного действия нет.':'Запись сохранена и перечитана.';
        status.classList.toggle('wf-error',!!result.refreshError);
        return result;
      }catch(e){
        if(e.definite)pending=null;
        status.textContent=accepted?'Запись сохранена, интерфейс не обновлён: '+e.message:(e.definite?'Запись отклонена: ':'Исход запроса не подтверждён; обновите данные и повторите тот же запрос: ')+e.message;
        status.classList.add('wf-error');
      }finally{busy=false;updateControls();}
    }
    updateControls();
    return {fields,buttons,refresh:refreshView,run,editPlacement,navigate,get view(){return view;},get pending(){return pending;},
      get busy(){return busy;},get status(){return status.textContent;},get text(){return container.textContent;}};
  }
  return {mount,fileTransport,declarationFor};
});
